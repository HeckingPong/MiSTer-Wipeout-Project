YO everyone, this is Hecker
This is a project for converting lost AY-3-8605 (Submarine) and AY-3-8606 (Wipeout) JavaScript simulators made by Cole Johnson (https://nerdstuffbycole.blogspot.com/) to MiSTerFPGA.
Cole hasn't been online for a few years, and these web projects went offline sometime in 2023. Using Wayback snapshots, i managed to recover (almost) all of the necessary files to run these simulators. I reorganized everything like the VisualP0NG-master, which was a repository for the AY-3-8500 (PONG) chip already made and converted to MiSTer by Cole himself.
With the help of anybody interested, i see this as an opportunity to contribute to the MiSTerFPGA community.
-------------------------------------------
Files Info:
-Useless Junk: Some of the files i used for Wayback extraction, i find it useless, but someone else might find it useful.
-AY-3-8500-MiSTer-master.zip: An original ZIP file containing the PONG chip's MiSTerFPGA files, the only chip converted by Cole himself. Perhaps it's useful as a blueprint for converting the rest.
-VisualP0NG-master: An original folder containing all of the files needed to run the PONG chip simulator. I used this as a sample to make folders for the next two games. As said in the README file, The development of this project is encouraged by Cole (https://nerdstuffbycole.blogspot.com/) and the Visual6502 (https://github.com/trebonian/visual6502) team.
-VisualSUBMARINE-master and VisualWIPE0UT-master: Pulled simulators and files from the Wayback Machine, created by myself. Credits go to respective creators though.
-------------------------------------------
For Anything else, Discord DMs are available: @hecker9494
Thats All !