var _____WB$wombat$assign$function_____=function(name){return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name))||self[name];};if(!self.__WB_pmw){self.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opens = _____WB$wombat$assign$function_____("opens");
/*
* Generated from source images by the ChipTools image processor
* Polygon and netlist source file of the AY-3-8605 (Submarine)
* Based on die photos from Sean Riddle and highlighting done by Cole Johnson
* (https://seanriddledecap.blogspot.com/2018/05/gi-ay-3-8605-ball-and-paddle-games-ay-3.html)
* This work is licensed under the Creative Commons Attribution 4.0 United States License. 
* To view a copy of this license, visit http://creativecommons.org/licenses/by/4.0/us/ or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.
*/
var nodenames = {
gnd: 170,
vcc: 1364,
reset: 331,
clk: 1365,
internal_reset: 912,
clock1: 1189,
clock2: 1341,
hrz_sync: 1314,
disable: 1337,
testmode1: 594,
pinStrobe1: 0,
pinStrobe2: 1,
pinEngineSound: 2,
pinFireSound: 3,
pinSonarSound: 4,
pinSubInput: 7,
pinDesInput: 14,
pinTest: 85,
pinSkill1: 656,
pinSkill2: 892,
pinFireT: 1117,
pinFireDC: 1345,
pinHueOut: 1359,
pinExpSound: 1366,
pinRVideo: 1362,
pinLVideo: 1361,
pinBackground: 1360,
pinBlanking: 1308,
pinColorburst: 1018,
pinSync: 776,
pinS1: 449,
pinS2: 205,
pinS3: 18,
pin2Sync: 772,
pin2Colorburst: 1009,
pin2Blanking: 1300,
pin2Background: 1350,
pin2LVideo: 1352,
pin2RVideo: 1355,
pin2HueOut: 1358,
pin2Strobe1: 16,
pin2Strobe2: 19,
NOT_SubPlayerColor: 650,
NOT_DesPlayerColor: 637,
goingLeftPoint: 208,
goingRightPoint: 235,
subGoRight: 493,
desGoRight: 491,
subGoLeft: 492,
desGoLeft: 490,
desNotMoving: 603,
subHumanControl: 920,
desHumanControl: 516,
subMoveDisable: 520,
desMoveDisable: 544,
turboPulldown1: 1153,
turboPulldown2: 1174,
turboToggle: 1154,
turboControl: 960,
isSpaceGame: 1011,
NOT_isSpaceGame: 269,};
}

/*
     FILE ARCHIVED ON 17:22:15 Jun 30, 2023 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 16:01:43 May 31, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.363
  load_resource: 86.032
  PetaboxLoader3.resolve: 46.319
  PetaboxLoader3.datanode: 12.864
*/